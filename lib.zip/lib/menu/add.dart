import 'package:flutter/material.dart';

class Add extends StatefulWidget{
  const Add({Key? key}) : super(key: key);
  
  @override
  
  State<Add> createState() => _AddState();
}

class _AddState extends State<Add>{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add',
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w600,
          fontSize: 30 // ทำให้ตัวอักษรหนาขึ้น
        ),),
        backgroundColor: Color.fromARGB(255, 255, 207, 35),
        centerTitle: true, // จัดให้ title อยู่กลาง),
      ),
     
    );
  }
} 