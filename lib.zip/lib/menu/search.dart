import 'package:flutter/material.dart';

class Search extends StatefulWidget{
  const Search({Key? key}) : super(key: key);
  
  @override
  
  State<Search> createState() => _ProfileState();
}

  Widget searchMenu(){
    return Padding(padding: EdgeInsetsDirectional.fromSTEB(0, 10, 0,10),
    child:  TextField(
      decoration:  const InputDecoration(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(
            5.0,
          )),
        ),
        filled: true,
        fillColor: Colors.white,
        contentPadding: EdgeInsets.all(15.0),
        hintText: 'Search Menu...',
      ),
      onChanged: (string){
       
      },
    ),
    );
    
  
   
  }

   Widget Menulist(){
    return Padding(
    padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 44),
    child: ListView(
    padding: EdgeInsets.zero,
    primary: false,
    shrinkWrap: true,
    scrollDirection: Axis.vertical,
    children: [
       Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0, 5, 0, 5),
        child: Container(
          width: 220,
          height: 240,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                blurRadius: 4,
                color: const Color.fromARGB(255, 128, 128, 128),
                offset: Offset(0, 2),
              )
            ],
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: const Color.fromARGB(255, 255, 255, 255),
              width: 1,
            ),
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(8, 8, 8, 8),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          'https://images.unsplash.com/photo-1597475681177-809cfdc76cd2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8YmVhY2hob3VzZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=900&q=60',
                          width: double.infinity,
                          height: double.infinity,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 8, 0, 0),
                  child: Text(
                    'Property Name',
                    style: TextStyle( color: Colors.black,
                    fontSize: 20,
                    fontWeight: FontWeight.w500),
                    
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(0, 4, 0, 8),
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: 'สูตรของ : ',
                              style: TextStyle(
                                color: Color.fromARGB(255, 75, 75, 75),
                                fontWeight: FontWeight.w400
                              ),
                            ),
                            TextSpan(
                              text: 'night',
                              style:TextStyle(
                                color: Color.fromARGB(255,75, 75, 75),
                                  fontWeight: FontWeight.w400
                              ),
                            )
                          ],
                          
                        ),
                      ),
                    ),

                  ],
                ),
              ],
            ),
          ),
        ),
      ),
       Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0, 5, 0, 5),
        child: Container(
          width: 220,
          height: 240,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                blurRadius: 4,
                color: const Color.fromARGB(255, 128, 128, 128),
                offset: Offset(0, 2),
              )
            ],
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: const Color.fromARGB(255, 255, 255, 255),
              width: 1,
            ),
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(8, 8, 8, 8),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          'https://images.unsplash.com/photo-1597475681177-809cfdc76cd2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8YmVhY2hob3VzZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=900&q=60',
                          width: double.infinity,
                          height: double.infinity,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 8, 0, 0),
                  child: Text(
                    'Property Name',
                    style: TextStyle( color: Colors.black,
                    fontSize: 20,
                    fontWeight: FontWeight.w500),
                    
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(0, 4, 0, 8),
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: 'สูตรของ : ',
                              style: TextStyle(
                                color: Color.fromARGB(255, 75, 75, 75),
                                fontWeight: FontWeight.w400
                              ),
                            ),
                            TextSpan(
                              text: 'night',
                              style:TextStyle(
                                color: Color.fromARGB(255,75, 75, 75),
                                  fontWeight: FontWeight.w400
                              ),
                            )
                          ],
                          
                        ),
                      ),
                    ),

                  ],
                ),
              ],
            ),
          ),
        ),
      ),
       Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0, 5, 0, 5),
        child: Container(
          width: 220,
          height: 240,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                blurRadius: 4,
                color: const Color.fromARGB(255, 128, 128, 128),
                offset: Offset(0, 2),
              )
            ],
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: const Color.fromARGB(255, 255, 255, 255),
              width: 1,
            ),
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(8, 8, 8, 8),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          'https://images.unsplash.com/photo-1597475681177-809cfdc76cd2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8YmVhY2hob3VzZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=900&q=60',
                          width: double.infinity,
                          height: double.infinity,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 8, 0, 0),
                  child: Text(
                    'Property Name',
                    style: TextStyle( color: Colors.black,
                    fontSize: 20,
                    fontWeight: FontWeight.w500),
                    
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(0, 4, 0, 8),
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: 'สูตรของ : ',
                              style: TextStyle(
                                color: Color.fromARGB(255, 75, 75, 75),
                                fontWeight: FontWeight.w400
                              ),
                            ),
                            TextSpan(
                              text: 'night',
                              style:TextStyle(
                                color: Color.fromARGB(255,75, 75, 75),
                                  fontWeight: FontWeight.w400
                              ),
                            )
                          ],
                          
                        ),
                      ),
                    ),

                  ],
                ),
              ],
            ),
          ),
        ),
      ),
       Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0, 5, 0, 5),
        child: Container(
          width: 220,
          height: 240,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                blurRadius: 4,
                color: const Color.fromARGB(255, 128, 128, 128),
                offset: Offset(0, 2),
              )
            ],
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: const Color.fromARGB(255, 255, 255, 255),
              width: 1,
            ),
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(8, 8, 8, 8),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          'https://images.unsplash.com/photo-1597475681177-809cfdc76cd2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8YmVhY2hob3VzZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=900&q=60',
                          width: double.infinity,
                          height: double.infinity,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 8, 0, 0),
                  child: Text(
                    'Property Name',
                    style: TextStyle( color: Colors.black,
                    fontSize: 20,
                    fontWeight: FontWeight.w500),
                    
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(0, 4, 0, 8),
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: 'สูตรของ : ',
                              style: TextStyle(
                                color: Color.fromARGB(255, 75, 75, 75),
                                fontWeight: FontWeight.w400
                              ),
                            ),
                            TextSpan(
                              text: 'night',
                              style:TextStyle(
                                color: Color.fromARGB(255,75, 75, 75),
                                  fontWeight: FontWeight.w400
                              ),
                            )
                          ],
                          
                        ),
                      ),
                    ),

                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      
    ]
    ),
    );
    
   
  }

class _ProfileState extends State<Search>{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search',
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w600,
          fontSize: 30 // ทำให้ตัวอักษรหนาขึ้น
        ),),
        backgroundColor: Color.fromARGB(255, 238, 186, 0),
        centerTitle: true, // จัดให้ title อยู่กลาง
      ),
      body: Container(
      color: Color.fromARGB(255, 255, 255, 255),
      padding: const EdgeInsets.all(5.0),
        child: Column(
          children:  <Widget> [
            searchMenu(),
            Menulist(),

          ],
        ),
     ),
    );
  }
} 