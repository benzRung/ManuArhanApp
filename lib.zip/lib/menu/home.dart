
import 'package:flutter/material.dart';

class Home extends StatefulWidget{
  const Home({Key? key}) : super(key: key);
  
  @override
  
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home>{


  Widget Menus(){
     return Card(
      color: Color.fromARGB(255, 255, 255, 255),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network('https://th.bing.com/th/id/R.a55f7d81254d3fa22efc5a1aa73e8fc5?rik=NatOQH1C9h2N9w&pid=ImgRaw&r=0',
                 width: 100,
                 height: 100,
                 fit: BoxFit.cover,
              ),
             
             ),
              title:const Text(
                "เมนู",
                  style: TextStyle(color: Color.fromARGB(255, 0, 0, 0),fontSize: 16)),
              subtitle:const Text(
                "สูตรของ",
                style: TextStyle(color: Color.fromARGB(255, 103, 103, 103),fontSize: 14)),
              trailing: const Icon(Icons.arrow_forward_ios),
              ),
              
              // onTap:(){
              //   Navigator.of(context).push(MaterialPageRoute(
              //     builder: (context) => UserDetail(
              //       user: users!.users[index],
              //       )));
              // },
              
          ],
          
        ),
      ),
    );
  }

  Widget TypeMenu(){
  return Container(
  width: 400,
  height: 210,
  decoration: BoxDecoration(
    color: Color.fromARGB(255, 255, 255, 255),
    borderRadius: BorderRadius.circular(20.0),
  ),
  child: Padding(
    padding: EdgeInsetsDirectional.fromSTEB(10, 20, 10, 0),
    child: GridView(
      padding: EdgeInsets.zero,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1,
      ),
      scrollDirection: Axis.vertical,
      children: [
        Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                'https://scontent.fbkk10-1.fna.fbcdn.net/v/t1.15752-9/395684880_309372751806442_8959863065145959382_n.png?_nc_cat=110&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeEUYagIjvxWL2yPewx2Acu7hQhXNGdEoGWFCFc0Z0SgZZnChcK-gLBPfS4dCPbwNTrLcO7IRoX9tTW4G9Q4o-NP&_nc_ohc=uxETXcVypeYAX8ZZv-d&_nc_ht=scontent.fbkk10-1.fna&oh=03_AdQ089saJ2Yvg98v_XffUUcnbFm1SNcCgFWyJGKnsnJi_A&oe=65645D78',
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
            ),
            Text(
              'ต้ม',
              style: TextStyle(fontSize: 14.0),
            ),
          ],
        ),
        Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                'https://scontent.fbkk10-1.fna.fbcdn.net/v/t1.15752-9/395584119_993161218456107_6385942543543942186_n.png?_nc_cat=111&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeHt87YRNbMI8oC5nhVR9oLhVwFQzhrA3XVXAVDOGsDddadrGseSjiW5G0DLQWvwOjKbvQgK3iK3vzE6MLGqZaKz&_nc_ohc=X9ZIGliWe9IAX-6MZGD&_nc_ht=scontent.fbkk10-1.fna&oh=03_AdTYq4NM9oeNqGeoOaTKXL6d-jx3LhnvhpD-U17JyE6Hjg&oe=65643305',
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
            ),
            Text(
              'Hello World',
              style: TextStyle(fontSize: 14.0),
             
            ),
          ],
        ),
        Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                'https://scontent.fbkk10-1.fna.fbcdn.net/v/t1.15752-9/395584119_993161218456107_6385942543543942186_n.png?_nc_cat=111&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeHt87YRNbMI8oC5nhVR9oLhVwFQzhrA3XVXAVDOGsDddadrGseSjiW5G0DLQWvwOjKbvQgK3iK3vzE6MLGqZaKz&_nc_ohc=X9ZIGliWe9IAX-6MZGD&_nc_ht=scontent.fbkk10-1.fna&oh=03_AdTYq4NM9oeNqGeoOaTKXL6d-jx3LhnvhpD-U17JyE6Hjg&oe=65643305',
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
            ),
            Text(
              'Hello World',
              style: TextStyle(fontSize: 14.0),
             
            ),
          ],
        ),
        Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                'https://scontent.fbkk10-1.fna.fbcdn.net/v/t1.15752-9/395584119_993161218456107_6385942543543942186_n.png?_nc_cat=111&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeHt87YRNbMI8oC5nhVR9oLhVwFQzhrA3XVXAVDOGsDddadrGseSjiW5G0DLQWvwOjKbvQgK3iK3vzE6MLGqZaKz&_nc_ohc=X9ZIGliWe9IAX-6MZGD&_nc_ht=scontent.fbkk10-1.fna&oh=03_AdTYq4NM9oeNqGeoOaTKXL6d-jx3LhnvhpD-U17JyE6Hjg&oe=65643305',
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
            ),
            Text(
              'Hello World',
              style: TextStyle(fontSize: 14.0),
              
            ),
          ],
        ),
        Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                'https://picsum.photos/seed/269/600',
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
            ),
            Text(
              'Hello World',
              style: TextStyle(fontSize: 14.0),
             
            ),
          ],
        ),
        Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                'https://picsum.photos/seed/313/600',
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
            ),
            Text(
              'Hello World',
              style: TextStyle(fontSize: 14.0),
              
            ),
          ],
        ),
        Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                'https://picsum.photos/seed/264/600',
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
            ),
            Text(
              'Hello World',
              style: TextStyle(fontSize: 14.0),
              
            ),
          ],
        ),
        Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                'https://picsum.photos/seed/918/600',
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
            ),
            Text(
              'Hello World',
              style: TextStyle(fontSize: 14.0),
             
            ),
          ],
        ),
      ],
    ),
  ),
);

}

Widget TypeMenu2(){
  return SafeArea(
          top: true,
          child: Container(
            width: 700,
            height: 181,
            decoration: BoxDecoration(
              color: Color.fromARGB(255, 255, 255, 255),
              borderRadius: BorderRadius.circular(0),
            ),
            child: ListView(
              padding: EdgeInsets.zero,
              scrollDirection: Axis.horizontal,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(10, 10, 10, 10),
                  child: Container(
                    width: 157,
                    height: 120,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 255, 255, 255),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.grey, // สีเงา
                            offset: Offset(0, 3), // ตำแหน่งแนวแกน x, y ของเงา
                            blurRadius: 6, // รัศมีของเงา
                        ),
                      ]
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Align(
                          alignment: AlignmentDirectional(0.00, 0.00),
                          child: Padding(
                            padding:
                                EdgeInsetsDirectional.fromSTEB(0, 20, 0, 0),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(80),
                              child: Image.network(
                                'https://picsum.photos/seed/463/600',
                                width: 100,
                                height: 100,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                          child: Text(
                            'Hello World',
                            style: TextStyle(
                                  fontFamily: 'Plus Jakarta Sans',
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                 Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(10, 10, 10, 10),
                  child: Container(
                    width: 157,
                    height: 100,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 255, 255, 255),
                      borderRadius: BorderRadius.circular(20),
                       boxShadow: [
                        BoxShadow(
                            color: Colors.grey, // สีเงา
                            offset: Offset(0, 3), // ตำแหน่งแนวแกน x, y ของเงา
                            blurRadius: 6, // รัศมีของเงา
                        ),
                      ]
                      
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Align(
                          alignment: AlignmentDirectional(0.00, 0.00),
                          child: Padding(
                            padding:
                                EdgeInsetsDirectional.fromSTEB(0, 20, 0, 0),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(80),
                              child: Image.network(
                                'https://picsum.photos/seed/463/600',
                                width: 100,
                                height: 100,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                          child: Text(
                            'Hello World',
                            style: TextStyle(
                                  fontFamily: 'Plus Jakarta Sans',
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                 Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(10, 10, 10, 10),
                  child: Container(
                    width: 157,
                    height: 100,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 255, 255, 255),
                      borderRadius: BorderRadius.circular(20),
                       boxShadow: [
                        BoxShadow(
                            color: Colors.grey, // สีเงา
                            offset: Offset(0, 3), // ตำแหน่งแนวแกน x, y ของเงา
                            blurRadius: 6, // รัศมีของเงา
                        ),
                      ]
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Align(
                          alignment: AlignmentDirectional(0.00, 0.00),
                          child: Padding(
                            padding:
                                EdgeInsetsDirectional.fromSTEB(0, 20, 0, 0),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(80),
                              child: Image.network(
                                'https://picsum.photos/seed/463/600',
                                width: 100,
                                height: 100,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                          child: Text(
                            'Hello World',
                            style: TextStyle(
                                  fontFamily: 'Plus Jakarta Sans',
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                 Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(10, 10, 10, 10),
                  child: Container(
                    width: 157,
                    height: 100,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 255, 255, 255),
                      borderRadius: BorderRadius.circular(20),
                       boxShadow: [
                        BoxShadow(
                            color: Colors.grey, // สีเงา
                            offset: Offset(0, 3), // ตำแหน่งแนวแกน x, y ของเงา
                            blurRadius: 6, // รัศมีของเงา
                        ),
                      ]
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Align(
                          alignment: AlignmentDirectional(0.00, 0.00),
                          child: Padding(
                            padding:
                                EdgeInsetsDirectional.fromSTEB(0, 20, 0, 0),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(80),
                              child: Image.network(
                                'https://picsum.photos/seed/463/600',
                                width: 100,
                                height: 100,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                          child: Text(
                            'Hello World',
                            style: TextStyle(
                                  fontFamily: 'Plus Jakarta Sans',
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
  );
}

  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('',
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w600,
          fontSize: 30 // ทำให้ตัวอักษรหนาขึ้น
        ),),
        backgroundColor: Color(0xFFFCAB0C),
        centerTitle: true, // จัดให้ title อยู่กลาง
      ),
     body: Container(
      color: Color.fromARGB(255, 255, 255, 255),
      padding: const EdgeInsets.all(5.0),
        child: Column(
          children:  <Widget> [
            // TypeMenu(),
            TypeMenu2(),
            // Row(
            //   children: [
            //       TypeMenu(),
            //   ],
            // ),
            Text("เมนูแนะนำ",
            style: TextStyle(color: Colors.black,
            fontSize: 30), 
            ),
            Menus(),
          ],
        ),
     ),
    );
  }
} 

  