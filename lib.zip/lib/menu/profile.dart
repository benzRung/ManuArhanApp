import 'package:flutter/material.dart';

class Profile extends StatefulWidget{
  const Profile({Key? key}) : super(key: key);
  
  @override
  
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile>{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile',
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w600,
          fontSize: 30 // ทำให้ตัวอักษรหนาขึ้น
        ),),
        backgroundColor: Color.fromARGB(255, 238, 186, 0),
        centerTitle: true, // จัดให้ title อยู่กลาง),
      ),
    );
  }
} 